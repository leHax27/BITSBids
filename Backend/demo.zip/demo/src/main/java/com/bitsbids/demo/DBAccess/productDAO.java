package com.bitsbids.demo.DBAccess;

import com.bitsbids.demo.entities.Product;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface productDAO extends JpaRepository<Product, String> {
    void deleteById(String id);

    List<Product> findByNameContainingIgnoreCase(String name);

    Optional<Product> findByUserId(String userId);
}
