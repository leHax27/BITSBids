package com.bitsbids.demo.services;

import com.bitsbids.demo.DBAccess.productDAO;
import com.bitsbids.demo.entities.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class productServiceImpl implements productService {

    @Autowired
    private productDAO productDao;

    @Override
    public List<Product> getProducts() {
        return productDao.findAll();
    }

    @Override
    public Optional<Product> getProduct(String userId) {
        return productDao.findByUserId(userId);
    }

    @Override
    public Product updateProduct(Product product) {
        Optional<Product> existingProduct = productDao.findById(product.getId());

        if (existingProduct.isPresent()) {
            Product updatedProduct = existingProduct.get();
            updatedProduct.setName(product.getName());
            updatedProduct.setDescription(product.getDescription());
            updatedProduct.setBidPrice(product.getBidPrice());
            updatedProduct.setBasePrice(product.getBasePrice());
            updatedProduct.setImageKey(product.getImageKey());
            updatedProduct.setEndTime(product.getEndTime());
            updatedProduct.setUserId(product.getUserId());

            productDao.save(updatedProduct);
            return updatedProduct;
        } else {
            return null;
        }
    }

    @Override
    public Product addProduct(Product product) {
        product.setEndTime(LocalDateTime.now().plusHours(24)); // Set a default end time (e.g., 24 hours from now)
        return productDao.save(product);
    }

    @Override
    public void deleteProduct(String id) {
        productDao.deleteById(id);
    }

    @Override
    public List<Product> searchProductsByName(String name) {
        // Use the custom query method from productDAO for searching by name
        return productDao.findByNameContainingIgnoreCase(name);
    }
}
